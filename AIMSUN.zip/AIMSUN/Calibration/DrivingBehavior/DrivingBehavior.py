import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *
from PyQt5.QtCore import QVariant


def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  

        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        # VehicleType to modify
        vehicleTypetId = 154

        # Initialize an empty list to store the data
        data = []
        
        with open('DrivingBehaviorParameter.csv', 'r') as file:
            for line in file.readlines():
                # Strip newline characters and split by comma
                row = line.strip().split(',')
                # Convert each value to float
                float_row = [float(value) for value in row]
                data.append(float_row)


        MinDist = data[0][0] #1~3
        MaxAcc =data[1][0] #2.5~3
        NormalDec = data[2][0] #4~5.3
        MaxDec = data[3][0] #5~9.3
        MinHeadway = data[4][0] #0.25~1.25
        SensitivityFactor = data[5][0] #0~1
        #HeadwayAggressiveness=1 #-1~1
        #AccAggressiveness=1 #-1~1

        # Get GKVehicle object.
        vehType = model.getCatalog().find( vehicleTypetId )
        if vehType != None and vehType.isA( "GKVehicle" ):
            #Cange vehicle parameters.
            #vehType.setDataValueByID( GKVehicle.maxSpeedMean, QVariant( maxDesiredSpeed[0] ))
            #vehType.setDataValueByID( GKVehicle.maxSpeedDev, QVariant( maxDesiredSpeed[1] ))
            #vehType.setDataValueByID( GKVehicle.maxSpeedMin, QVariant( maxDesiredSpeed[2] ))
            #vehType.setDataValueByID( GKVehicle.maxSpeedMax, QVariant( maxDesiredSpeed[3] ))

        #min dist/spacing
            vehType.setDataValueByID( GKVehicle.minDistMean, QVariant( MinDist ))
            vehType.setDataValueByID( GKVehicle.minDistMin, QVariant( MinDist*0.8 ))
            vehType.setDataValueByID( GKVehicle.minDistMax, QVariant( MinDist*1.2 ))

        #max acceleration
            vehType.setDataValueByID( GKVehicle.maxAccelMean, QVariant( MaxAcc ))
            vehType.setDataValueByID( GKVehicle.maxAccelMin, QVariant( MaxAcc*0.8 ))
            vehType.setDataValueByID( GKVehicle.maxAccelMax, QVariant( MaxAcc*1.2 ))
        #normal deceleration
            vehType.setDataValueByID( GKVehicle.normalDecelMean, QVariant( NormalDec ))
            #vehType.setDataValueByID( GKVehicle.normalDecelDev, QVariant( normalDeceleration[1] ))
            vehType.setDataValueByID( GKVehicle.normalDecelMin, QVariant( NormalDec*0.8 ))
            vehType.setDataValueByID( GKVehicle.normalDecelMax, QVariant( NormalDec*1.2 ))
        #max deceleration
            vehType.setDataValueByID( GKVehicle.maxDecelMean, QVariant( MaxDec  ))
            vehType.setDataValueByID( GKVehicle.maxDecelMin, QVariant( MaxDec *0.8 ))
            vehType.setDataValueByID( GKVehicle.maxDecelMax, QVariant( MaxDec *1.2 ))

        #min headway
            vehType.setDataValueByID( GKVehicle.minimunHeadwayMean, QVariant( MinHeadway))
            vehType.setDataValueByID( GKVehicle.minimunHeadwayMin, QVariant( MinHeadway*0.8 ))
            vehType.setDataValueByID( GKVehicle.minimunHeadwayMax, QVariant( MinHeadway*1.2 ))

        #sensitivity factor
            vehType.setDataValueByID( GKVehicle.sensitivityFactorMean, QVariant(SensitivityFactor))

        #Headway Aggressiveness
            #vehType.setDataValueByID( GKVehicle.CFAggressivenessMean, QVariant(HeadwayAggressiveness))

        #Acc Aggressiveness
            #vehType.setDataValueByID( GKVehicle.accelerationAggressivenessMean, QVariant(AccAggressiveness))


        
        model.getCommander().addCommand( None )
        print ("Done")

        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"