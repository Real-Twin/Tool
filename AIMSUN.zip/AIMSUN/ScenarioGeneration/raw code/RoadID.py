import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  

        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        extidset2  = []
        nodeType = model.getType( "GKNode" )
        for types in model.getCatalog().getUsedSubTypesFromType( nodeType  ):
            for s in types.values():
                extidset2.append(s.getExternalId())

        nodeType = model.getType( "GKNode" )
        outernodes = []
        outcount = [0] * len(extidset2)
        incount = [0] * len(extidset2)
        #deal with to outside
        for types in model.getCatalog().getUsedSubTypesFromType( nodeType  ):
            for s in types.values():
                extID = s.getExternalId()
                exit = s.getExitSections()
                if s.getExternalId() not in extidset2:
                    continue;
                # outnum = 1
                for i in exit: # all exiting section i from node s
                    exit2 = i
                    nextnode = exit2.getDestination()
                    for nnn in range(0,100):  # loop used to find the desination node/outside
                        if nextnode == None: #outside
                            #exit2poly = exit2.calculatePolylineWithoutPedestrianCrossings(exit2.getPoints(),0,None)
                            #npoint = len(exit2poly)
                            #desti = 'outside(' + str(exit2poly[npoint-1].x) +',' + str(exit2poly[npoint-1].y) + ')'
                            ind = extidset2.index(s.getExternalId())
                            outcount [ind] +=1
                            desti = 'out' + str(outcount [ind])
                            intid = s.getId()
                            if intid not in outernodes:
                                outernodes.append(intid)
                            break;
                        elif nextnode.getExternalId() in extidset2:
                            desti = nextnode.getExternalId()
                            break;
                        else:
                            exits = nextnode.getExitSections()
                            exit2 = exits[0] # assume that whenever a section has two exits, there should be a junction from openDrive
                            nextnode = exit2.getDestination()
                    
                    exit2 = i
                    nextnode = exit2.getDestination()
                    namenum = 1
                    for nnn in range(0,1000):  # loop used to name the sections
                        if nextnode == None: #outside
                            name =	extID + '-' + str(namenum) + '-' + desti
                            exit2.setExternalId(name)					
                            break;
                        elif nextnode.getExternalId() in extidset2:
                            name =	extID + '-' + str(namenum) + '-' + desti
                            exit2.setExternalId(name)					
                            break;
                        else:
                            name =	extID + '-' + str(namenum) + '-' + desti
                            exit2.setExternalId(name)
                            namenum +=1
                            exits = nextnode.getExitSections()
                            exit2 = exits[0] # assume that whenever a section has two exits, there should be a junction from openDrive
                            nextnode = exit2.getDestination()


        #deal with from outside
        #find all outside to inside node
        nodeType = model.getType( "GKNode" )
        innernodes= []
        for types in model.getCatalog().getUsedSubTypesFromType( nodeType  ):
            for s in types.values():
                extID = s.getExternalId()
                entrance = s.getEntranceSections()
                if s.getExternalId() not in extidset2:
                    continue;
                # outnum = 1
                for i in entrance: # all exiting section i from node s
                    entrance2 = i
                    lastnode = entrance2.getOrigin()
                    for nnn in range(0,1000):  # loop used to find the desination node/outside
                        if lastnode == None: #outside
                            entrance2poly = entrance2.calculatePolylineWithoutPedestrianCrossings(entrance2.getPoints(),0,None)
                            npoint = len(entrance2poly)
                            intid = s.getId()
                            if intid not in innernodes:
                                innernodes.append(intid)
                            break;
                        elif lastnode.getExternalId() in extidset2:
                            break;
                        else:
                            exits = lastnode.getEntranceSections()
                            entrance2 = exits[0] # assume that whenever a section has two exits, there should be a junction from openDrive
                            lastnode = entrance2.getOrigin()


        #print(innernodes)
        for s in innernodes:
            onode =	 model.getCatalog().find(s)
            entrance = onode.getEntranceSections()
            extID = onode.getExternalId()
            for i in entrance: # all exiting section i from node s
                flagin = 0
                entr2 = i
                lastnode = entr2.getOrigin()
                namenum1 = 1
                for nnn in range(0,1000):  # loop used to find the desination node/outside
                    if lastnode == None: #outside
                        #entr2poly = entr2.calculatePolylineWithoutPedestrianCrossings(entr2.getPoints(),0,None)
                        #origin = 'outside(' + str(entr2poly[0].x) +',' + str(entr2poly[0].y) + ')'
                        ind = extidset2.index(model.getCatalog().find(s).getExternalId())
                        incount [ind] +=1 # form outside1 outside2 etc purpose
                        origin =  'in' + str(incount [ind])
                        break;
                    elif lastnode.getExternalId() in extidset2:
                        flagin = 1
                        break;
                    else:
                        ent = lastnode.getEntranceSections()
                        entr2 = ent[0] # assume that whenever a section has two exits, there should be a junction from openDrive
                        lastnode = entr2.getOrigin()
                        namenum1 +=1	
                #if flagin == 1:
                    #break;

                entr2 = i
                lastnode = entr2.getOrigin()
                namenum2 = 1
                namenum = namenum1
                for nnn in range(0,1000):  # loop used to find the desination node/outside
                    if lastnode == None: #outside
                        name =	origin + '-' + str(namenum) + '-' + extID
                        entr2.setExternalId(name)					
                    elif lastnode.getExternalId() in extidset2:
                        break;
                    else:
                        name =	origin + '-' + str(namenum) + '-' + extID
                        entr2.setExternalId(name)
                        namenum = namenum1-namenum2
                        namenum2 +=1	
                        ent = lastnode.getEntranceSections()
                        entr2 = ent[0] # assume that whenever a section has two exits, there should be a junction from openDrive
                        lastnode = entr2.getOrigin()

        # print(incount)
        # print(extidset)

        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"