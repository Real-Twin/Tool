import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  

        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        # file = 'C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/chatt3.xodr'
        layer = model.getCatalog().find(27)
        model.importFile(argv[2], layer, GKPoint(0,0,0),GKBBox())
        # model.importFile(file, layer, GKPoint(0,0,0),GKBBox())
        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"