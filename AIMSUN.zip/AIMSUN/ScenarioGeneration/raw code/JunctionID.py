import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  

        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        nodeType = model.getType( "GKNode" )
        for types in model.getCatalog().getUsedSubTypesFromType( nodeType  ):
            for s in types.values():
                print ("node ID: %i External ID: %s" % (s.getId(), s.getExternalId()))
                curID = s.getExternalId()
                for i in range(0,len(curID)):
                    j = len(curID)-i-1
                    if curID[j] == "_":
                        newid = curID[(j+1):len(curID)]
                        s.setExternalId(newid)
                        #print (newid)
                        #print ("node ID: %i External ID: %s" % (s.getId(), s.getExternalId()))

        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"