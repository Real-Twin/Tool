# Nicolas Muhlich
# New York Grid: 16x16

# import json NM
# READ THIS BEFORE ANYTHING
#
# HOW TO USE THIS SCRIPT
# 1st create a link
# 2nd create a new python script and paste this code
# 3rd add the created script to the section script menu (the other tab in the script window)
# 4th right click on the link and excecute the script
# 5th now we need to set the od matrix to use cars
# 6th create a new traffic demand, and add the OD matrix to this traffic demand
# 8th create a new dynamic scenario and add the master control plan and the traffic demand
	#set the detection interval to 2 min and load the API python code
# 9th add a new experiment to the dynamic scenario
	#set the simulation step to 1 sec, the route choice to logit/dynamic and 5 possible paths / 5 min update interval
# 10th add a replication to the experiment
# RUN THE EXPERIMENT

#SET the detector reporting interval to 2 min in the Dynamic Scenario Properties
#Set the aggregate script

def fileDump(output, name = "output.json"):
	fo = open(name, "w+")
	print ("Name of the file: ", fo.name)
	print ("Closed or not : ", fo.closed)
	print ("Opening mode : ", fo.mode)
	print ("Softspace flag : ", fo.softspace)
	jsonoutput = json.dumps(output, sort_keys=True, indent=4, separators=(',', ': '))
	fo.write(jsonoutput)
	fo.close

colnum = 2 # NM
rownum = 2 # NM
intSize = 20
pi = 3.14159

length = 200 #target.length2D()

# new inputs from Andys code
odDemand = 0.01 #set total OD demand
probePercentage = 0.0 #set probe percentage
carODdemand = odDemand*(1 - probePercentage)
dtFactor = 1 #sets demand scaling factor for downtown subnetwork
dtCarLoadDemand = carODdemand*dtFactor
carVehTypeId = 53 #this shouldn't change, but verify
inner = 5 #col number defining inner edge of subnetwork
outter = 13 #col number defining outter edge of subnetwork + 1

def Westbound(row,col):
    newSection = target.clone()
    points = newSection.getPoints()
    interx = inter[row][col]["GKPoint"].x
    intery = inter[row][col]["GKPoint"].y
    points[0].set(interx + intSize / 2.0 + length, intery + 5 , 0) # +5: different from Andys code
    points[1].set(interx + intSize / 2.0 , intery + 5 , 0)
    inter[row][col]["in"].append(newSection)
    inter[row][col+1]["out"].append(newSection)
    newSection.setPoints(points)
    #newSection.setPoints(newSection.getPoints())
    model.getGeoModel().add(target.getLayer(), newSection)

def Eastbound(row,col):
	newSection = target.clone()
	points = newSection.getPoints()
	interx = inter[row][col]["GKPoint"].x
	intery = inter[row][col]["GKPoint"].y
	points[0].set(interx - intSize / 2.0 - length, intery - 5 , 0) # -5: different from Andys code
	points[1].set(interx - intSize / 2.0 , intery - 5 , 0)
	inter[row][col]["in"].append(newSection)
	inter[row][col-1]["out"].append(newSection)
	newSection.setPoints(points)
	model.getGeoModel().add(target.getLayer(), newSection)

def Northbound(row,col):
	newSection = target.clone()
	points = newSection.getPoints()
	interx = inter[row][col]["GKPoint"].x
	intery = inter[row][col]["GKPoint"].y
	points[0].set(interx + 5 , intery - intSize / 2.0 - length , 0) # +5: different from Andys code
	points[1].set(interx + 5 , intery - intSize / 2.0 , 0)
	inter[row][col]["in"].append(newSection)
	inter[row-1][col]["out"].append(newSection)
	newSection.setPoints(points)
	model.getGeoModel().add(target.getLayer(), newSection)

def Southbound(row,col):
	newSection = target.clone()
	points = newSection.getPoints()
	interx = inter[row][col]["GKPoint"].x
	intery = inter[row][col]["GKPoint"].y
	points[0].set(interx - 5 , intery + intSize / 2.0 +length , 0) # -5: different from Andys code
	points[1].set(interx - 5 , intery + intSize / 2.0 , 0)
	inter[row][col]["in"].append(newSection)
	inter[row+1][col]["out"].append(newSection)
	newSection.setPoints(points)
	model.getGeoModel().add(target.getLayer(), newSection)

#FUNCTION THAT SOMEONE ELSE SHOULD HAVE CREATED
#defines the functions to create a new signal, phase,  detector, centroid, od matrix, etc.
def NewGKControlPlanSignal(node, name = "New Signal"):
	signal = GKSystem.getSystem().newObject( "GKControlPlanSignal", model )
	node.addSignal(signal)
	signal.setName(name)
	return signal

def NewGKDetector(GKSection, name = "New Detector"):
	GKDetector = GKSystem.getSystem().newObject( "GKDetector", model )
	GKDetector.setLanes( 0, 1 )
	GKDetector.setLength( 4.0 ) # different from Andys code
	GKDetector.setPosition( GKSection.length2D() - 6.5 ) # different from Andys code
	GKSection.addTopObject( GKDetector)
	model.getGeoModel().add( GKSection.getLayer(), GKDetector)
	return GKDetector

def NewGKControlJunction(GKControlPlan, GKNode):
	control = GKControlPlan.createControlJunction(GKNode.getId())
	control.setControlJunctionType(2)
	control.setCycle(60) # NM
	control.setOffset(0)
	control.setYellowTime(3) # NM
	control.setRedPercentageInYellowTime(0) # added from Andy
	return control

def NewGKControlJunctionstopcontrol(GKControlPlan, GKNode):
	control = GKControlPlan.createControlJunction(GKNode.getId())
	control.setControlJunctionType(1)
	return control

def NewGKControlPhase(GKControlJunction,GKControlPlanSignal):
	GKControlPhase = GKControlJunction.createPhase()
	GKControlPhase.addSignal(GKControlPlanSignal)
	GKControlPhase.setFrom(0)
	GKControlPhase.setDuration(26) # NM
	return GKControlPhase

# everything from here to next hash added from Andy
def New2GKControlPhase(GKControlJunction,GKControlPlanSignal):
	GKControlPhase = GKControlJunction.createPhase()
	GKControlPhase.addSignal(GKControlPlanSignal)
	GKControlPhase.setFrom(30)
	GKControlPhase.setDuration(26)
	return GKControlPhase

def New3GKControlPhase(GKControlJunction,GKControlPlanSignal):
	GKControlPhase = GKControlJunction.createPhase()
	GKControlPhase.addSignal(GKControlPlanSignal)
	GKControlPhase.setFrom(26)
	GKControlPhase.setDuration(4)
	GKControlPhase.setInterphase(1)
	return GKControlPhase

def New4GKControlPhase(GKControlJunction,GKControlPlanSignal):
	GKControlPhase = GKControlJunction.createPhase()
	GKControlPhase.addSignal(GKControlPlanSignal)
	GKControlPhase.setFrom(56)
	GKControlPhase.setDuration(4)
	GKControlPhase.setInterphase(1)
	return GKControlPhase
# all this was added from Andys Code

def NewGKControlPlan( only = False , name = "Starting Configuration"):
	newControlPlan = GKSystem.getSystem().newObject( "GKControlPlan", model )
	newControlPlan.setName(name)
	folderName = "GKModel::controlPlans"
	folder = model.getCreateRootFolder().findFolder( folderName )
	if folder == None:
		folder = GKSystem.getSystem().createFolder(model.getCreateRootFolder(), folderName )
	if only:
		for plan in folder.getContents().values():
			folder.remove(plan)
			if plan.canBeDeleted():
				cmd = plan.getDelCmd()
				model.getCommander().addCommand( cmd )
	folder.append( newControlPlan )
	return newControlPlan

def NewGKMasterControlPlan(GKControlPlan, only = True, name = "Starting Configuration"):
	GKMasterControlPlan = GKSystem.getSystem().newObject( "GKMasterControlPlan", model )
	GKMasterControlPlan.setName(name)
	ScheduleMasterControlPlanItem = GKScheduleMasterControlPlanItem()
	ScheduleMasterControlPlanItem.setFrom(0)
	ScheduleMasterControlPlanItem.setDuration(3600) # for one hour, different from Andy
	ScheduleMasterControlPlanItem.setZone(1)
	ScheduleMasterControlPlanItem.setControlPlan(GKControlPlan)
	GKMasterControlPlan.addToSchedule(ScheduleMasterControlPlanItem)
	folderName = "GKModel::masterControlPlans"
	folder = model.getCreateRootFolder().findFolder( folderName )
	if folder == None:
		folder = GKSystem.getSystem().createFolder(model.getCreateRootFolder(), folderName )
	if only:
		for plan in folder.getContents().values():
			folder.remove(plan)
			if plan.canBeDeleted():
				cmd = plan.getDelCmd()
				model.getCommander().addCommand( cmd )
	folder.append( GKMasterControlPlan )
	return GKMasterControlPlan

def NewGKCentroid(GKPoint):
	GKCentroid = GKSystem.getSystem().newObject( "GKCentroid", model )
	GKCentroid.setFromPosition(GKPoint)
	GKCentroid.setConsideredPercentages(0)
	# GKCentroid.setActive(True) NM
	GKCentroid.setUseInMatrix(True)
	model.getGeoModel().add(target.getLayer(), GKCentroid)
	return GKCentroid

#def NewGKODMatrix(GKCentroidConfiguration, name = "New OD Matrix"):
#	GKODMatrix = GKSystem.getSystem().newObject( "GKODMatrix", model )
#	GKODMatrix.setName( name )
#	GKODMatrix.setCentroidConfiguration(GKCentroidConfiguration)
#	return GKODMatrix

# few more functions in Andys Code (MatrixProbeLoad, MatrixCarPeak, etc.)

# this was added from Andys code
def NewGKODMatrixCarLoad(GKCentroidConfiguration, name = "Car OD Matrix Load" ):
	GKODMatrix = GKSystem.getSystem().newObject( "GKODMatrix", model )
	GKODMatrix.setName( name )
	GKODMatrix.setFrom( QTime(0, 0) )
	GKODMatrix.setDuration( GKTimeDuration(1, 0, 0) )
	vehicleType = model.getType( "GKVehicle" )
	vehicles = model.getCatalog().getObjectsByType( vehicleType )
	if vehicles != None :
		i = 0
		for vehicle in vehicles.values():
			if (vehicle.getId() == carVehTypeId):
				GKODMatrix.setVehicle( vehicle )
				i = i+1
	GKODMatrix.setCentroidConfiguration(GKCentroidConfiguration)
	return GKODMatrix

def NewGKCentroidConfiguration(only = False, name = "Centroids Configuration"):
	GKCentroidConfiguration = GKSystem.getSystem().newObject( "GKCentroidConfiguration", model )
	GKCentroidConfiguration.setName(name)
	
	folderName = "GKModel::centroidsConf"
	folder = model.getCreateRootFolder().findFolder( folderName )
	if folder == None:
		folder = GKSystem.getSystem().createFolder(model.getCreateRootFolder(), folderName )
	if only:
		for plan in folder.getContents().values():
			folder.remove(plan)
			if plan.canBeDeleted():
				cmd = plan.getDelCmd()
				model.getCommander().addCommand( cmd )
	folder.append( GKCentroidConfiguration )
	return GKCentroidConfiguration

def NewGKCenConnection(GKGeoObject, to = True):
	GKCenConnection = GKSystem.getSystem().newObject( "GKCenConnection", model )
	if to:
		GKCenConnection.setConnectionType(0)
	else:
		GKCenConnection.setConnectionType(1)
	GKCenConnection.setConnectionObject(GKGeoObject)
	return GKCenConnection

# two more function in Andys Code (getVehicle and createVehicle)

#LOGIC TO CREATE THE NETWORK

def turn(inSection,outSection,node,signalGroup):
	# This code generates the geometry of the
	delta = inSection.getExitAngle() - outSection.getEntranceAngle()
	
	if (delta > 3.5):
		delta = delta - 2*pi
	if (delta < -3.5):
		delta = delta + 2*pi
	
	if (abs(delta)>3):
		#uturn / a left turn
		slane = 0
		eLane = 0	# commented in Andys Code
	else:
		if (abs(delta)<1):
			#thru
			sLane = 0
			eLane = 1	# commented in Andys Code
		else:
			if (delta>0):
				#right
				sLane = 1
				eLane = 1	# commented in Andys Code
			else:
				#left
				sLane = 0
				eLane = 0	# commented in Andys Code
		#take note that u turns are not created
		turning = GKSystem.getSystem().newObject( "GKTurning", model )
		turning.setOrigin(inSection)
		turning.setDestination(outSection)
		turning.setOriginLanes(sLane,eLane)	# different in Andys code
		turning.setDestinationLanes(sLane,eLane)	# different in Andys code
		turning.setConnection(inSection, outSection)
		turning.curve()
		turning.setAutoSpeed(True)
		turning.setWarningIndicator(2)
		node.addTurning(turning, True, True)
		signalGroup.addTurning(turning)

# AA and AL
def turn2(inSection, outSection, node, signalGroup):
	# This code generates the geometry of the
	delta = inSection.getExitAngle() - outSection.getEntranceAngle()

	if (delta > 3.5):
		delta = delta - 2 * pi
	if (delta < -3.5):
		delta = delta + 2 * pi

	if (abs(delta) > 3):
		# uturn / a left turn
		slane = 0
		eLane = 0  # commented in Andys Code
	else:
		if (abs(delta) < 1):
			# thru
			sLane = 0
			eLane = 1  # commented in Andys Code
		else:
			if (delta > 0):
				# right
				sLane = 1
				eLane = 1  # commented in Andys Code
			else:
				# left
				sLane = 0
				eLane = 0  # commented in Andys Code
		# take note that u turns are not created
		turning = GKSystem.getSystem().newObject("GKTurning", model)
		turning.setOrigin(inSection)
		turning.setDestination(outSection)
		turning.setOriginLanes(sLane, eLane)  # different in Andys code
		turning.setDestinationLanes(sLane, eLane)  # different in Andys code
		turning.setConnection(inSection, outSection)
		turning.curve()
		turning.setAutoSpeed(True)
		turning.setWarningIndicator(0)
		node.addTurning(turning, True, True)
		signalGroup.addTurning(turning)



def cloneNetwork(inter):
	network = list(range(0,len(inter)))
	print(str(len(inter)) + " x " + str(len(inter[0])))
	for row in range(0,len(inter)):
		network[row] = list(range(0,len(inter[0])))
		for col in range(0,len(inter[0])):
			network[row][col] = {}
			network[row][col]["O/D"] = inter[row][col]["O/D"]
			
			if network[row][col]["O/D"]:
				network[row][col]["internal?"] = inter[row][col]["internal?"]
				network[row][col]["GKCentroid"] = inter[row][col]["GKCentroid"].getId()
				
				network[row][col]["in"] = []
				for section in inter[row][col]["in"]:
					print(str(section.getId()))
					network[row][col]["in"].append(section.getId())
				
				network[row][col]["out"] = []
				for section in inter[row][col]["out"]:
					network[row][col]["out"].append(section.getId())

				network[row][col]["GKDetectors"] = []
				for detector in inter[row][col]["GKDetectors"]:
					network[row][col]["GKDetectors"].append(detector.getId())

	return network

#HERE IS WERE THE LOGIC STARTS

# the following for loop creates a metrix where each entry represents an intersection. It also creates an aimsun point with the coordinates of each intersection
print ("creating the network variable")
inter = list(range(0,rownum+2))
for row in range(0,rownum+2):
	inter[row]= list(range(0,colnum+2))
	for col in range(0,colnum+2):
		inter[row][col] = {} # "GKPoint" : 0 , "in" : [] , "out" : [] , "signal" : [] }
		inter[row][col]["O/D"] = False
		inter[row][col]["GKPoint"] = GKPoint()
		inter[row][col]["GKPoint"].set(col * (length + intSize), row * (length + intSize), 0)
		inter[row][col]["in"] = []
		inter[row][col]["out"] = []
		inter[row][col]["GKDetectors"] = []
		inter[row][col]["GKControlPlanSignal"] = []
		if (row in range(1,rownum+1)) and (col in range(1,colnum+1)):
			inter[row][col]["internal?"] = True
		else:
			inter[row][col]["internal?"] = False	

# Here is where sections are created. In reality each setion is a clone of the one currently selected
print ("creating the links")		# this section is different in Andys code
for row in range(1,rownum+1):
	for col in range(0,colnum+2):
		inter[row][col]["O/D"] = True
		if (col == 0): 
			Westbound(row,col)
		else:
			if (col == colnum + 1):
				Eastbound(row,col)
			else:
				Westbound(row,col)
				Eastbound(row,col)

for row in range(0,rownum+2):
	for col in range(1,colnum+1):
		inter[row][col]["O/D"] = True
		if (row == 0): 
			Southbound(row,col)
		else:
			if (row == rownum + 1):
				Northbound(row,col)
			else:
				Southbound(row,col)
				Northbound(row,col)

# here is where intersections (nodes) are created
# also we create a control plan and an OD matrix
print ("creating the Nodes, Control Plan and OD Matrix")  # this section is different in Andys code, since he has more functions to call
newControlPlan = NewGKControlPlan(True)
NewGKMasterControlPlan(newControlPlan) 
newCentroidConfiguration = NewGKCentroidConfiguration(True)
# newODMatrix = NewGKODMatrix(newCentroidConfiguration)
#newODMatrix.setEnableStore(True)
#newCentroidConfiguration.addODMatrix(newODMatrix)

# this was added from Andys code
newODMatrixCarLoad = NewGKODMatrixCarLoad(newCentroidConfiguration)
newODMatrixCarLoad.setEnableStore(True)
matrixCarIdLoad = newODMatrixCarLoad.getId()
newCentroidConfiguration.addODMatrix(newODMatrixCarLoad)


print ("creating the Nodes and Control Plan")


for row in range(1,rownum + 1):
	for col in range(1,rownum + 1):
		newNode = GKSystem.getSystem().newObject("GKNode", model)
		inter[row][col]["GKNode"] = newNode
		newNode.setYellowBox(True)
		model.getGeoModel().add(target.getLayer(), newNode) # can not be node!!!! check1!!!!

		newSignalEW = NewGKControlPlanSignal(newNode, "Eastbound-Westbound")
		inter[row][col]["GKControlPlanSignal"].append(newSignalEW)

		newSignalNS = NewGKControlPlanSignal(newNode, "Northbound-Southbound")
		inter[row][col]["GKControlPlanSignal"].append(newSignalNS)

		if (row>=0 and col>=0): # AA
			for inSection in inter[row][col]["in"]:
				for outSection in inter[row][col]["out"]:
					if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
						signalGroup = newSignalEW
					else:
						signalGroup = newSignalNS
					turn2(inSection, outSection, newNode, signalGroup)
				newDetector = NewGKDetector(inSection)
				inter[row][col]["GKDetectors"].append(newDetector)
		# elif (row%7==4 and col%7!=4): # horizontal A  vertical L
		# 	for inSection in inter[row][col]["in"][0:2]: # 0 and 1 are west and east bound
		# 		for outSection in inter[row][col]["out"]:
		# 			if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
		# 				signalGroup = newSignalEW
		# 			else:
		# 				signalGroup = newSignalNS
		# 			turn2(inSection, outSection, newNode, signalGroup)
		# 		newDetector = NewGKDetector(inSection)
		# 		inter[row][col]["GKDetectors"].append(newDetector)
		# 	for inSection in inter[row][col]["in"][2:4]:  # 2 and 3 are north and south bound, stop controlled
		# 		for outSection in inter[row][col]["out"]:
		# 			if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
		# 				signalGroup = newSignalEW
		# 			else:
		# 				signalGroup = newSignalNS
		# 			turn(inSection, outSection, newNode, signalGroup)
		# 		newDetector = NewGKDetector(inSection)
		# 		inter[row][col]["GKDetectors"].append(newDetector)
		# elif (row%7!=4 and col%7==4): # horizontaal L  vertical A
		# 	for inSection in inter[row][col]["in"][0:2]: # 0 and 1 are west and east bound, stop controlled
		# 		for outSection in inter[row][col]["out"]:
		# 			if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
		# 				signalGroup = newSignalEW
		# 			else:
		# 				signalGroup = newSignalNS
		# 			turn(inSection, outSection, newNode, signalGroup)
		# 		newDetector = NewGKDetector(inSection)
		# 		inter[row][col]["GKDetectors"].append(newDetector)
		# 	for inSection in inter[row][col]["in"][2:4]:  # 2 and 3 are north and south bound
		# 		for outSection in inter[row][col]["out"]:
		# 			if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
		# 				signalGroup = newSignalEW
		# 			else:
		# 				signalGroup = newSignalNS
		# 			turn2(inSection, outSection, newNode, signalGroup)
		# 		newDetector = NewGKDetector(inSection)
		# 		inter[row][col]["GKDetectors"].append(newDetector)
		# else: #LL
		# 	for inSection in inter[row][col]["in"]:
		# 		for outSection in inter[row][col]["out"]:
		# 			if (abs(inSection.getExitAngle()) > 2 or abs(inSection.getExitAngle()) < 1):
		# 				signalGroup = newSignalEW
		# 			else:
		# 				signalGroup = newSignalNS
		# 			turn(inSection, outSection, newNode, signalGroup)
		# 		newDetector = NewGKDetector(inSection)
		# 		inter[row][col]["GKDetectors"].append(newDetector)


		if (row>=0 and col>=0):
			newControl = NewGKControlJunction(newControlPlan, newNode)
			newPhaseEW = New2GKControlPhase(newControl, newSignalEW)
			newPhaseEW1 = New4GKControlPhase(newControl, newNode)
			newPhaseNS = NewGKControlPhase(newControl, newSignalNS)
			newPhaseNS1 = New3GKControlPhase(newControl, newNode)
		else:
			newControl = NewGKControlJunctionstopcontrol(newControlPlan, newNode)









#here is where we add the centroids
print ("creating the Centroids")
for row in range(0, rownum + 2):
	for col in range(0, colnum + 2):
		if inter[row][col]["O/D"]:
			newCentroid = NewGKCentroid(inter[row][col]["GKPoint"])
			inter[row][col]["GKCentroid"] = newCentroid
			newCentroidConfiguration.addCentroid(newCentroid)
			for inSection in inter[row][col]["in"]:
				newConnection = NewGKCenConnection(inSection, False)
				newCentroid.addConnection(newConnection)
			for outSection in inter[row][col]["out"]:
				newConnection = NewGKCenConnection(outSection, True)
				newCentroid.addConnection(newConnection)

#here is where we populate the OD matrix
# this code is different in Andys Code, maybe reason why OD matrix has errors
print ("creating the OD Matrix")
# for ro in range(0, rownum + 2):
#	for co in range(0, colnum + 2):
	#	if (not(inter[ro][co]["internal?"]) and inter[ro][co]["O/D"]):
		#	for rd in range(0, rownum + 2):
			#	for cd in  range(0, colnum + 2):
				#	if (inter[rd][cd]["internal?"] and inter[rd][cd]["O/D"]):
					#	if (inter[ro][co] != inter[rd][cd]) and ((cd in range(9,13)) and rd in range(9,13)):
						#	newODMatrix.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], 50)

# Andys code was used here
#here is where we populate the loading car OD matrix
for ro in range(0, rownum + 2):
	for co in range(0, colnum + 2):
		if inter[ro][co]["O/D"]:
			for rd in range(0, rownum + 2):
				for cd in  range(0, colnum + 2):
					if (abs(ro-rd) + abs(co-cd)==20):
						if (inter[rd][cd]["internal?"] and inter[rd][cd]["O/D"]):
							if inter[ro][co] != inter[rd][cd]:
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], carODdemand)
						if (not(inter[rd][cd]["internal?"]) and inter[rd][cd]["O/D"]):
							if inter[ro][co] != inter[rd][cd]:
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], carODdemand)
						if (inter[rd][cd]["internal?"] and inter[rd][cd]["O/D"]):
							if (inter[ro][co] != inter[rd][cd]) and ((cd in range(inner,outter)) and rd in range(inner,outter)):
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], dtCarLoadDemand)
					else:
						if (inter[rd][cd]["internal?"] and inter[rd][cd]["O/D"]):
							if inter[ro][co] != inter[rd][cd]:
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], 0)
						if (not(inter[rd][cd]["internal?"]) and inter[rd][cd]["O/D"]):
							if inter[ro][co] != inter[rd][cd]:
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], 0)
						if (inter[rd][cd]["internal?"] and inter[rd][cd]["O/D"]):
							if (inter[ro][co] != inter[rd][cd]) and ((cd in range(inner,outter)) and rd in range(inner,outter)):
								newODMatrixCarLoad.setTrips(inter[ro][co]["GKCentroid"], inter[rd][cd]["GKCentroid"], 0)

# the following code is also fom Andys code
def getDemandFolder( model ):
	folderName = "GKModel::trafficDemand"
	folder = model.getCreateRootFolder().findFolder( folderName )
	if folder == None:
		folder = GKSystem.getSystem().createFolder( model.getCreateRootFolder(), folderName )
	return folder

def createDemand( model, name ):
	trafficDemand = GKSystem.getSystem().newObject( "GKTrafficDemand", model )
	trafficDemand.setName( name )
	folder = getDemandFolder( model )
	folder.append( trafficDemand )
	return trafficDemand

# trafficDemandState = createDemand( model, "Traffic Demand State" )
# demandStateId = trafficDemandState.getId()
trafficDemandMatrix = createDemand( model, "Traffic Demand Matrix" )
demandMatrixId = trafficDemandMatrix.getId()

def setDemandItem( model, demandState, item ):
	if item.getVehicle() == None:
		model.getLog().addError( "Invalid Demand Item: no vehicle" )
	else:
		schedule = GKScheduleDemandItem()
		schedule.setTrafficDemandItem( item )
		schedule.setFrom( simStartHr * 3600 )
		schedule.setDuration( simDurHr * 3600 )
		demandState.addToSchedule( schedule )

matrix_carLoad = model.getCatalog().find( matrixCarIdLoad )
demandMatrix = model.getCatalog().find( demandMatrixId )

if demandMatrix != None and demandMatrix.isA("GKTrafficDemand"):
	demandMatrix.removeSchedule()
	# Add the car and probe matrices
	if matrix_carLoad != None and matrix_carLoad.isA("GKODMatrix"):
		schedule = GKScheduleDemandItem()
		schedule.setTrafficDemandItem( matrix_carLoad )
		schedule.setFrom( 0 * 3600 )
		schedule.setDuration( 1 * 3600 )
		demandMatrix.addToSchedule( schedule )
	model.getCommander().addCommand( None )
else :
	print ("Demand does not exist")
						

# print "Saving the Network Configuration File" NM
# network = cloneNetwork(inter) NM
# fileDump(network, "Network_v4.json") NM

model.getCommander().addCommand( None )