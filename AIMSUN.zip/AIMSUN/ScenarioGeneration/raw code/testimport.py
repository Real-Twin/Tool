import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    if len( argv ) < 2:
        print (str("Usage: aconsole -script %s ANG_FILE MATRIX_ID"%(argv[0])))
        return -1
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  
        print ("load network")



        # Variables used to configure this script
        flowsFilePath = 'C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/flow.txt'
        # turnsFilePath = 'c:/tmp/turns.txt'

        # Returns (and creates if needed) the folder for the traffic state
        #
        def getStateFolder( model ):
            folderName = "GKModel::trafficStates"
            folder = model.getCreateRootFolder().findFolder( folderName )
            if folder == None:
                folder = GKSystem.getSystem().createFolder( model.getCreateRootFolder(), folderName )
            return folder

        # Creates a traffic state with the given name
        #
        def createState( model, name ):
            state = GKSystem.getSystem().newObject( "GKTrafficState", model )
            state.setName( name )
            folder = getStateFolder( model )
            folder.append( state )
            return state

        # Finds an object using its identifier and checks if it is really a section
        #
        def findSection( model, entry ):
            section = model.getCatalog().find( int(entry) )
            if section.isA( "GKSection" ) == False:
                section = None
            return section

        # Reads a file containing the input flows
        #
        def importStateFlow( model, state, fileName ):
            for line in open( fileName, "r" ).readlines():
                # take the value on each line
                tokens = line.split( "," )
                # Reset the column counter
                i = 0
                for entry in tokens:
                    # First column contains the id of the section
                    if i == 0:
                        section = findSection( model, entry )
                    # Second column contains the flow
                    elif i == 1:
                        flow = float(entry)
                        # Set the value if the section is valid
                        if section != None: 
                            state.setEntranceFlow( section, None, flow )
                    i = i + 1   

        # Reads a file containing the turning proportions
        #
        def importStateTurns( model, state, fileName ):
            for line in open( fileName, "r" ).readlines():
                # take the value on each line
                tokens = line.split( "," )
                # Reset the column counter
                i = 0
                for entry in tokens:
                    # First column contains the id of the section
                    if i == 0:
                        section = findSection( model, entry )
                    # Second column contains the if of the to section
                    elif i == 1:
                        toSection = findSection( model, entry )
                    # Third column contains the percentage
                    elif i == 2:
                        percentage = float(entry)
                        # Set the value if the section is valid
                        if section != None and toSection != None:
                            state.setTurningPercentage( section, toSection, None, percentage )
                    i = i + 1   

        # Entry code, the script starts here

        # Create a new state
        state = createState( model, "New State" )
        # Imports the input flows
        importStateFlow( model, state, flowsFilePath )
        # Import the turning proportions

        # importStateTurns( model, state, turnsFilePath )


        model.getCommander().addCommand( None )

        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))
