import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  

        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        filePath = argv[2]
        for line in open( filePath, "r" ).readlines():
            # take the value on each line
            tokens = line.split( "," )
            # Reset the column counter
            i = 0
            for entry in tokens:
                # First column contains the id of the section
                if i == 0:
                    section =  model.getCatalog().findObjectByExternalId(entry)
                # Second column contains the flow
                elif i == 1:
                    speed = float(entry)*3.6
                    section.setSpeed(speed)
                    # Set the value if the section is valid
                i = i + 1	
        print('done')

        sectionType = model.getType( "GKSection" )
        for types in model.getCatalog().getUsedSubTypesFromType(sectionType):
            for s in types.values():
                if s.getSpeed() == 50: 
                    print('check section with ID:')
                    print(s.getId())

        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"