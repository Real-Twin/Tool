from setuptools import setup, find_packages

setup(
    name='RealtwinTest0417',
    version='1',
    author='Guanhao',
    description='Test of Aimsun',
    packages=find_packages(),
    install_requires=[
        'numpy',
        'matplotlib',
        'subprocess'
    ]
)
