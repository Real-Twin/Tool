import sys

from PyANGBasic import *
from PyANGKernel import *
from PyANGConsole import *

def main( argv ):
    # Start a Console
    console = ANGConsole()
    # Load a network
    if console.open( argv[1] ):
        model = console.getModel()  
        
        # put my code from Aimsun here, remember to use nodepat++ to convert tab to space
        # Returns (and creates if needed) the folder for the traffic state
        sectionType = model.getType( "GKSection" )
        inflow_sec = []
        for types in model.getCatalog().getUsedSubTypesFromType(sectionType):
            for s in types.values():
                if s.getOrigin() == None: 
                    inflow_sec .append(s.getId())

        #
        def getStateFolder( model ):
            folderName = "GKModel::trafficStates"
            folder = model.getCreateRootFolder().findFolder( folderName )
            if folder == None:
                folder = GKSystem.getSystem().createFolder( model.getCreateRootFolder(), folderName )
            return folder

        # Creates a traffic state with the given name
        #
        def createState( model, name,time_beg,duration):
            
            state = GKSystem.getSystem().newObject( "GKTrafficState", model )
            
            state.setName( name )
            
            state.setInterval(QTime.fromString(time_beg),GKTimeDuration.fromString(duration))
            
            #print(state.getFrom())
            #print(state.getDuration())
            vehicleType = model.getType( "GKVehicle" )
            vehicles = model.getCatalog().getObjectsByType( vehicleType )
            if vehicles != None :
                for vehicle in vehicles.values():
                    if (vehicle.getName() == 'Car'):
                        state.setVehicle( vehicle )
            folder = getStateFolder( model )
            folder.append( state )
            
            return state

        # Finds an object using its identifier and checks if it is really a section
        #
        def findSection( model, entry ):
            section = model.getCatalog().find( int(entry) )
            if section.isA( "GKSection" ) == False:
                section = None
            return section

        def findSectionext( model, entry ):
            section = model.getCatalog().findObjectByExternalId(str(entry))
            if section.isA( "GKSection" ) == False:
                section = None
            return section

        # Reads a file containing the input flows
        #
        def importStateFlow( model, state, fileName,beg_time,end_time):
            for line in open( fileName, "r" ).readlines():
                # take the value on each line
                tokens = line.split( "," )
                # Reset the column counter
                i = 0
                flag = 1
                for entry in tokens:
                    if i == 0: # time begiin
                        if float(entry)<beg_time:
                            flag = 0
                    elif i == 1:# time end
                        if float(entry)>end_time:
                            flag = 0
                    elif i == 2: # external id
                        # section = findSection( model, entry ) # search using external id
                        section = findSectionext( model, entry )
                    # Second column contains the flow
                    elif i == 3:
                        flow = float(entry)
                        # Set the value if the section is valid
                        if section != None and flag ==1: 
                            state.setEntranceFlow( section, None, flow )
                    i = i + 1	

            for	 enterid in inflow_sec:
                flow = state.getEntranceFlow(model.getCatalog().find(enterid), None)
                if flow == -1:
                    flow = state.setEntranceFlow(model.getCatalog().find(enterid), None, 0)
                    

        # Reads a file containing the turning proportions
        #
        def importStateTurns( model, state, fileName, beg_time,end_time):
            for line in open( fileName, "r" ).readlines():
                # take the value on each line
                tokens = line.split( "," )
                # Reset the column counter
                i = 0
                flag = 1
                for entry in tokens:
                    # First column contains the id of the section
                    if i == 0: # time begiin
                        if float(entry)<beg_time:
                            flag = 0			
                    elif i == 1:# time end
                        if float(entry)>end_time:
                            flag = 0	
                    elif i == 2:
                        # section = findSection( model, entry ) # search using internal id
                        section = findSectionext( model, entry )
                    # Second column contains the if of the to section
                    elif i == 3:
                        # toSection = findSection( model, entry ) # search using internal id
                        toSection = findSectionext( model, entry )
                    # Third column contains the percentage
                    elif i == 4:
                        percentage = float(entry)
                        # Set the value if the section is valid
                        if section != None and toSection != None and flag ==1: 
                            state.setTurningPercentage( section, toSection, None, percentage )
                    i = i + 1	

        # Entry code, the script starts here
        # Create a new state


        for tbeg in range(15,18):
            for tmin in range(0,60,10):
                if tmin == 0:
                    name = "traffic state from" + str(tbeg) + ":00:00 to "+	 str(tbeg)+ ":10:00"
                    time_beg = str(tbeg) + ":00:00"
                elif tmin==50:
                    name = "traffic state from" + str(tbeg) + ":50:00 to "+	 str(tbeg+1)+ ":00:00"
                    time_beg = str(tbeg) + ":"+ str(tmin) + ":00 "		
                else:
                    name = "traffic state from" + str(tbeg) + ":"+ str(tmin) + ":00 to "+  str(tbeg)+ ":"+ str(tmin+10) + ":00"
                    time_beg = str(tbeg) + ":"+ str(tmin) + ":00 "
                duration =	"00:10:00"
                
                state = createState( model, name,time_beg,duration)
            # Imports the input flows
                flowsFilePath = argv[2]
                importStateFlow( model, state, flowsFilePath,tbeg*3600,(tbeg+1)*3600)
            # Import the turning proportions
                turnsFilePath = argv[3]
                importStateTurns( model, state, turnsFilePath,(tbeg*3600+tmin*60),(tbeg*3600+(tmin+10)*60))


        model.getCommander().addCommand( None )
        print ("Done")


        console.save( argv[1])
        console.close()
    else:
        console.getLog().addError( "Cannot load the network" )
        print ("cannot load network")


if __name__ == "__main__":
    sys.exit(main(sys.argv))



# run the following code in cmd: "C:/Users/ggx/Aimsun/aconsole.exe" -script "C:/Users/ggx/Downloads/aimsun_pytest/runpy/model/testimport.py" "C:/Users/ggx/Downloads/aimsun_pytest/runpy/Model/runpy.ang"